'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  AdminStep1, AdminStep2, AdminStep3, AdminStep4, AdminStep5,
  AdminStep6, AdminStep7, AdminStep8, AdminStep9
} from './AdminAssessmentSteps';

export default function AssessmentWizard({ patient }: { patient: any }) {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<any>(() => {
    // Parse JSON strings back to arrays if needed for UI, or handle carefully
    const parsed = { ...patient };
    try { if (typeof parsed.previousSurgeries === 'string') parsed.previousSurgeries = JSON.parse(parsed.previousSurgeries); } catch(e){}
    try { if (typeof parsed.previousTreatmentsTried === 'string') parsed.previousTreatmentsTried = JSON.parse(parsed.previousTreatmentsTried); } catch(e){}
    try { if (typeof parsed.comorbidities === 'string') parsed.comorbidities = JSON.parse(parsed.comorbidities); } catch(e){}
    // Parse documents if available
    try { if (typeof parsed.documents === 'string') parsed.documents = JSON.parse(parsed.documents); } catch(e){}
    return parsed;
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const totalSteps = 9;

  const updateData = (fields: any) => {
    setFormData((prev: any) => ({ ...prev, ...fields }));
  };

  const handleNext = () => {
    if (currentStep < totalSteps) setCurrentStep((prev) => prev + 1);
  };

  const handleBack = () => {
    if (currentStep > 1) setCurrentStep((prev) => prev - 1);
  };

  const handleSave = async () => {
    setIsSubmitting(true);
    setError('');

    try {
      const res = await fetch(`/api/patient/${patient.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!res.ok) {
        throw new Error('Failed to save assessment');
      }

      router.push(`/admin`);
      router.refresh();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="glass-panel p-6 sm:p-8 animate-fade-in w-full max-w-4xl mx-auto mt-8">
      <div className="mb-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">
          Clinical Assessment: <span className="text-teal-400">{patient.name}</span>
        </h1>
        <div className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full text-teal-400 bg-teal-400/10 border border-teal-400/20">
          Slide {currentStep} of {totalSteps}
        </div>
      </div>

      <div className="wizard-progress mb-8">
        {Array.from({ length: totalSteps }).map((_, idx) => {
          const stepNum = idx + 1;
          let className = 'wizard-step';
          if (stepNum === currentStep) className += ' active';
          else if (stepNum < currentStep) className += ' completed';
          return <div key={idx} className={className}></div>;
        })}
      </div>

      <div className="min-h-[450px]">
        {currentStep === 1 && <AdminStep1 data={formData} updateData={updateData} />}
        {currentStep === 2 && <AdminStep2 data={formData} updateData={updateData} />}
        {currentStep === 3 && <AdminStep3 data={formData} updateData={updateData} />}
        {currentStep === 4 && <AdminStep4 data={formData} updateData={updateData} />}
        {currentStep === 5 && <AdminStep5 data={formData} updateData={updateData} />}
        {currentStep === 6 && <AdminStep6 data={formData} updateData={updateData} />}
        {currentStep === 7 && <AdminStep7 data={formData} updateData={updateData} />}
        {currentStep === 8 && <AdminStep8 data={formData} updateData={updateData} />}
        {currentStep === 9 && <AdminStep9 data={formData} updateData={updateData} />}
      </div>

      {error && <div className="text-red-500 mt-4 text-center">{error}</div>}

      <div className="flex justify-between mt-8 border-t pt-6" style={{ borderColor: 'var(--glass-border)' }}>
        <button
          onClick={handleBack}
          disabled={currentStep === 1 || isSubmitting}
          className={`btn ${currentStep === 1 ? 'opacity-50 cursor-not-allowed bg-slate-800' : 'btn-secondary'}`}
        >
          Back
        </button>
        <div className="flex gap-4">
          <button onClick={handleSave} disabled={isSubmitting} className="btn bg-slate-800 hover:bg-slate-700 text-white">
            {isSubmitting ? 'Saving...' : 'Save & Exit'}
          </button>
          {currentStep < totalSteps ? (
            <button onClick={handleNext} className="btn btn-primary">
              Next
            </button>
          ) : (
            <button onClick={handleSave} disabled={isSubmitting} className="btn btn-primary">
              {isSubmitting ? 'Saving...' : 'Complete Assessment'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
