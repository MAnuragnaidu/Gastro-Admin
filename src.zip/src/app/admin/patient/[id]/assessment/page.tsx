import { prisma } from '@/lib/prisma';
import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import AssessmentWizard from './AssessmentWizard';
import LogoutButton from '../../../LogoutButton';

export default async function AdminAssessmentPage({ params }: { params: Promise<{ id: string }> }) {
  const cookieStore = await cookies();
  const userRole = cookieStore.get('userRole');

  if (userRole?.value !== 'ADMIN') {
    redirect('/');
  }

  const resolvedParams = await params;

  const patient = await prisma.patient.findUnique({
    where: { id: parseInt(resolvedParams.id) },
    include: { user: true },
  });

  if (!patient) {
    return <div className="text-center mt-20 text-white">Patient not found</div>;
  }

  return (
    <div className="min-h-screen bg-[#070c16] text-[#e2e8f0]">
      <nav className="bg-[#0d1526] border-b border-white/5 px-8 h-14 flex items-center justify-between">
        <div className="font-semibold text-[15px] text-[#f1f5f9]">
          MyGastro<span className="text-blue-500">.Ai</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-slate-400 bg-white/5 border border-white/10 px-2.5 py-1 rounded font-medium">
            Admin
          </span>
          <LogoutButton />
        </div>
      </nav>

      <div className="container mx-auto px-4 pb-20">
        <AssessmentWizard patient={patient} />
      </div>
    </div>
  );
}
